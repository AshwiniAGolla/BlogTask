﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using BlogTaskApi.Models;
using BlogTaskApi.BL;
using System.Web.Http.Cors;

namespace BlogTaskApi.Controllers.Blog
{
    [Authorize]
    [EnableCors(headers:"*", methods:"*", origins:"*")]
    public class PostController : ApiController
    {
        repo<sp_Fetch_Posts_Result> repopost;
        public PostController()
        {
            repopost = new repo<sp_Fetch_Posts_Result>(new BlogTaskEntities());
        }
        [Route("api/Post")]
        public IEnumerable<sp_Fetch_Posts_Result> GetPost()
        {
            string sp = "[sp_Fetch_Posts]{0}";
            object[] para = { 0 };
            return repopost.ExecuteQuery(sp, para);
        }

        // GetAllPost
        [Route("api/Post/{id}")]
        public sp_Fetch_Posts_Result GetAllPost(int id)
        {
            string sp = "[sp_Fetch_Posts] {0}";
            object[] para = { id };
            return repopost.ExecuteQuery(sp, para).ToList()[0];
        }
    }
}
