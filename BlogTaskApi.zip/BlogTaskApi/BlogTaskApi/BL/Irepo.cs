﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using BlogTaskApi.Models;

namespace BlogTaskApi.BL
{
    interface Irepo<T> : IDisposable where T : class
    {
        IEnumerable<T> ExecuteQuery(string spQuery, object[] parameters);
        int ExecuteCommand(string spQuery, object[] parameters);

    }
}