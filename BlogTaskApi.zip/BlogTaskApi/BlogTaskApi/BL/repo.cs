﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using BlogTaskApi.Models;
using System.Data.Entity;

namespace BlogTaskApi.BL
{
    public class repo<T> : Irepo<T> where T : class
    {
        BlogTaskEntities context = null;
        private DbSet<T> entities = null;

        public repo(BlogTaskEntities contxt)
        {
            this.context = contxt;
            entities = context.Set<T>();
        }

        public IEnumerable<T> ExecuteQuery(string spQuery, object[] parameters)
        {
            using(context = new BlogTaskEntities())
            {
                return context.Database.SqlQuery<T>(spQuery, parameters).ToList();
            }
        }

        public int ExecuteCommand(string spQuery, object[] parameters)
        {
            int result = 0;
            try
            {
                using (context = new BlogTaskEntities())
                {
                    result = context.Database.SqlQuery<int>(spQuery, parameters).FirstOrDefault();
                }
            }
            catch { }
            return result;
        }

        private bool disposed = false;
        protected virtual void Dispose(bool disposing)
        {
            if (!this.disposed)
            {
                if (disposing)
                {
                    context.Dispose();
                }
            }
            this.disposed = true;
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }
    }
}